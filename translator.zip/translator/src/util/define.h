/* 
 * File:   define.h
 * Author: yaoyinbo
 *
 * Created on October 25, 2013, 9:43 PM
 */

#ifndef DEFINE_H
#define	DEFINE_H

#ifndef TRUE_STRING
#define TRUE_STRING "True"
#endif

#ifndef FALSE_STRING
#define FALSE_STRING "False"
#endif


#endif	/* DEFINE_H */

